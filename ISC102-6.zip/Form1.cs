﻿// 教育部工科技藝競賽 102 年第六題 多矩陣相乘運算次數
/// 漆家豪 於 海青工商 2024/3/3
using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;

namespace _102_6
{
    public partial class Form1 : Form
    {
        public const int X0 = 10, Y0 = 10, DX = 30, DY = 20, MaxN = 10, MinN = 3, MaxV = 100, MinV = 0;
        public const string MSG1 = "矩陣相乘的次序為：";
        public const string MSG2 = "最少的乘法運算次數：";
        System.Windows.Forms.TextBox[,] matrixTxt = new System.Windows.Forms.TextBox[MaxN, 2];
        System.Windows.Forms.Label[] label = new System.Windows.Forms.Label[MaxN];
        private static List<Matrix> matrix = new List<Matrix>();

        /// <summary>
        /// 設定矩陣資料(依據 numberTbx 內容)
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Run_Click(object sender, EventArgs e)
        {
            // 檢查輸入數字的有效性
            if (!int.TryParse(numberTbx.Text, out int n) || n < MinN || n > MaxN)
            {
                MessageBox.Show($"輸入數字必須在 {MinN} ~ {MaxN} 之間。", "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            //安排所有 label 及 textBox 位置
            groupBox1.Visible = true;
            for (int i = 0; i < n; i++)
            {
                label[i].Visible = matrixTxt[i, 0].Visible = matrixTxt[i, 1].Visible = true;
            }
            for (int i = n; i < MaxN; i++)
            {
                label[i].Visible = matrixTxt[i, 0].Visible = matrixTxt[i, 1].Visible = false;
            }
            groupBox1.Height = matrixTxt[n - 1, 0].Top + matrixTxt[n - 1, 0].Height + DY;
            AnsLab1.Location = new System.Drawing.Point(X0, groupBox1.Top + groupBox1.Height + DY * 2);
            AnsLab2.Location = new System.Drawing.Point(X0, AnsLab1.Top + AnsLab1.Height + DY * 2);
            Height = AnsLab2.Top + AnsLab2.Height + DY * 4;
        }

        /// <summary>
        /// 分析矩陣結合順序
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void analyzeBtn_Click(object sender, EventArgs e)
        {
            // 清空列表，以防止重複添加
            matrix.Clear();

            //檢查矩陣資料是否符合規定，並添加用戶輸入的數據到 matrix 列表中
            for (int i = 0; i < int.Parse(numberTbx.Text); i++)
            {
                if (int.TryParse(matrixTxt[i, 1].Text, out int number))
                {
                    if (number >= MinV && number <= MaxV)
                    {
                        Matrix x = new Matrix(string.Concat(Matrix.FirstNAME, (i + 1).ToString()), int.Parse(matrixTxt[i, 0].Text), int.Parse(matrixTxt[i, 1].Text), 0);
                        matrix.Add(x);
                    }
                    else
                    {
                        MessageBox.Show($"行列值應該在 {MinV} ~ {MaxV} 範圍內。", "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        return;
                    }
                }
                else
                {
                    MessageBox.Show($"{i + 1} 的行列值資料錯誤。", "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }
            }

            //調用 Combine 方法處理 matrix 列表
            string nameCombine = "";
            int sum = 0;
            Matrix.Combine(matrix, ref nameCombine, ref sum);

            // 顯示結果
            AnsLab1.Text = MSG1 + nameCombine;
            AnsLab2.Text = MSG2 + sum.ToString();
            int w1 = AnsLab1.Left + AnsLab1.Width + DX;
            int w2 = analyzeBtn.Left + analyzeBtn.Width + DX;
            Width = Math.Max(w1, w2); //彈性調整 form 的寬度
        }

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            int ty = Y0, tx = MtxRowTbx1.Width, indexTab = MtxRowTbx1.TabIndex, bakTab = 100;
            for (int i = 0; i < 10; i++)
            {
                label[i] = (System.Windows.Forms.Label)this.Controls.Find("mtxLab" + (i + 1), true)[0];
                label[i].Text = $"M{i + 1}{(i < 9 ? "  " : "")}的矩陣大小：";
                label[i].BorderStyle = BorderStyle.None;
                label[i].AutoSize = true;
                label[i].Location = new System.Drawing.Point(X0, ty + DY);
                label[i].Visible = false;

                matrixTxt[i, 0] = (System.Windows.Forms.TextBox)this.Controls.Find("MtxRowTbx" + (i + 1), true)[0];
                matrixTxt[i, 0].Location = new System.Drawing.Point(X0 + label[i].Width + DX, ty + DY);

                matrixTxt[i, 1] = (System.Windows.Forms.TextBox)this.Controls.Find("MtxColTbx" + (i + 1), true)[0];
                matrixTxt[i, 0].Width = matrixTxt[i, 1].Width = tx;
                matrixTxt[i, 0].Height = matrixTxt[i, 1].Height = label[i].Height;
                matrixTxt[i, 1].Location = new System.Drawing.Point(matrixTxt[i, 0].Left + matrixTxt[i, 0].Width + DX, ty + DY);
                matrixTxt[i, 1].TabIndex = ++indexTab;

                ty = label[i].Top + label[i].Height;
                matrixTxt[i, 0].Visible = matrixTxt[i, 1].Visible = label[i].Visible = false;

                if (i > 0)
                {
                    matrixTxt[i, 0].TabIndex = ++bakTab;
                    matrixTxt[i, 0].ReadOnly = true;
                }

                matrixTxt[i, 1].TextChanged += (textBoxSender, textBoxE) =>
                {
                    for (int row = 0; row < matrixTxt.GetLength(0); row++)// 查找匹配的 textBoxSender
                        for (int col = 0; col < matrixTxt.GetLength(1); col++)
                            if (matrixTxt[row, col] == textBoxSender)
                                // 找到匹配的控制項，然後設置相應的索引
                                if ((row >= 0) && (row < 9))
                                    matrixTxt[row + 1, 0].Text = matrixTxt[row, 1].Text;
                    return;
                };
            }

            AnsLab1.Location = new System.Drawing.Point(X0, ty + DY * 3);
            AnsLab1.Text = MSG1;
            AnsLab2.Location = new System.Drawing.Point(X0, AnsLab1.Top + AnsLab1.Height + DY * 2);
            AnsLab2.Text = MSG2;
            groupBox1.Width = matrixTxt[9, 1].Left + matrixTxt[9, 1].Width + DX;
            groupBox1.Visible = false;
            Height = 300;
        }
    }

    class Matrix
    {
        public const string FirstNAME = "M", LM = "<", RM = ">";
        private int _row, _col, _val;
        private string _name;
        public int row { get { return _row; } set { _row = value; } }
        public int col { get { return _col; } set { _col = value; } }
        public int val { get { return _val; } set { _val = value; } }
        public string name { get { return _name; } set { _name = value; } }

        public Matrix(string n, int r, int c, int v)
        {
            name = n;
            row = r;
            col = c;
            val = v;
        }

        /// <summary>
        /// 定義兩矩陣相乘的方式
        /// </summary>
        /// <param name="a">前矩陣</param>
        /// <param name="b">後矩陣</param>
        /// <returns>a.b 的結果</returns>
        public static Matrix operator *(Matrix a, Matrix b)
        {
            Matrix c = new Matrix($"{LM}{a.name} {b.name}{RM}", a.row, b.col, a.row * a.col * b.col);
            return c;
        }

        /// <summary>
        /// 結合方式運算
        /// </summary>
        /// <param name="matrix">矩陣列表</param>
        /// <param name="name">最後結合的方式運算式</param>
        /// <param name="sum">運算次數</param>
        public static void Combine(List<Matrix> matrix, ref string name, ref int sum)
        {
            while (matrix.Count > 1)
            {
                ///貪婪法，找出最大的 a行與 (a+1)列，先結合。
                var maxMatrix = matrix.Select((t, index) => new { Matrix = t, Index = index })
                          .Where(item => item.Index < matrix.Count - 1)
                          .OrderByDescending(item => item.Matrix.col)
                          .First();

                int maxIndex = maxMatrix.Index;
                Matrix a = matrix[maxIndex];
                Matrix b = matrix[maxIndex + 1];
                Matrix c = a * b;
                sum += c.val;
                matrix.RemoveAt(maxIndex);
                matrix.RemoveAt(maxIndex);
                matrix.Insert(maxIndex, c);
            }
            name = matrix[0].name;
        }
    }
}

