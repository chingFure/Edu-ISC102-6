﻿using System.Windows.Forms;

namespace _102_6
{
    partial class Form1
    {
        /// <summary>
        /// 設計工具所需的變數。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清除任何使用中的資源。
        /// </summary>
        /// <param name="disposing">如果應該處置受控資源則為 true，否則為 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 設計工具產生的程式碼

        /// <summary>
        /// 此為設計工具支援所需的方法 - 請勿使用程式碼編輯器修改
        /// 這個方法的內容。
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.numberTbx = new System.Windows.Forms.TextBox();
            this.Run = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.mtxLab10 = new System.Windows.Forms.Label();
            this.mtxLab7 = new System.Windows.Forms.Label();
            this.mtxLab8 = new System.Windows.Forms.Label();
            this.mtxLab9 = new System.Windows.Forms.Label();
            this.mtxLab4 = new System.Windows.Forms.Label();
            this.mtxLab5 = new System.Windows.Forms.Label();
            this.mtxLab6 = new System.Windows.Forms.Label();
            this.MtxRowTbx5 = new System.Windows.Forms.TextBox();
            this.MtxColTbx10 = new System.Windows.Forms.TextBox();
            this.MtxRowTbx6 = new System.Windows.Forms.TextBox();
            this.MtxColTbx5 = new System.Windows.Forms.TextBox();
            this.mtxLab3 = new System.Windows.Forms.Label();
            this.mtxLab2 = new System.Windows.Forms.Label();
            this.MtxRowTbx7 = new System.Windows.Forms.TextBox();
            this.MtxColTbx9 = new System.Windows.Forms.TextBox();
            this.MtxRowTbx8 = new System.Windows.Forms.TextBox();
            this.MtxColTbx8 = new System.Windows.Forms.TextBox();
            this.MtxRowTbx9 = new System.Windows.Forms.TextBox();
            this.MtxColTbx7 = new System.Windows.Forms.TextBox();
            this.MtxRowTbx10 = new System.Windows.Forms.TextBox();
            this.MtxColTbx6 = new System.Windows.Forms.TextBox();
            this.MtxRowTbx4 = new System.Windows.Forms.TextBox();
            this.MtxColTbx3 = new System.Windows.Forms.TextBox();
            this.MtxRowTbx3 = new System.Windows.Forms.TextBox();
            this.MtxColTbx4 = new System.Windows.Forms.TextBox();
            this.MtxRowTbx2 = new System.Windows.Forms.TextBox();
            this.MtxColTbx2 = new System.Windows.Forms.TextBox();
            this.MtxRowTbx1 = new System.Windows.Forms.TextBox();
            this.MtxColTbx1 = new System.Windows.Forms.TextBox();
            this.mtxLab1 = new System.Windows.Forms.Label();
            this.analyzeBtn = new System.Windows.Forms.Button();
            this.AnsLab2 = new System.Windows.Forms.Label();
            this.AnsLab1 = new System.Windows.Forms.Label();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(17, 26);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(260, 24);
            this.label1.TabIndex = 0;
            this.label1.Text = "請輸入有幾個矩陣相乘?";
            // 
            // numberTbx
            // 
            this.numberTbx.Location = new System.Drawing.Point(297, 20);
            this.numberTbx.Name = "numberTbx";
            this.numberTbx.Size = new System.Drawing.Size(100, 36);
            this.numberTbx.TabIndex = 1;
            // 
            // Run
            // 
            this.Run.Location = new System.Drawing.Point(417, 12);
            this.Run.Name = "Run";
            this.Run.Size = new System.Drawing.Size(91, 52);
            this.Run.TabIndex = 2;
            this.Run.Text = "確認";
            this.Run.UseVisualStyleBackColor = true;
            this.Run.Click += new System.EventHandler(this.Run_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.mtxLab10);
            this.groupBox1.Controls.Add(this.mtxLab7);
            this.groupBox1.Controls.Add(this.mtxLab8);
            this.groupBox1.Controls.Add(this.mtxLab9);
            this.groupBox1.Controls.Add(this.mtxLab4);
            this.groupBox1.Controls.Add(this.mtxLab5);
            this.groupBox1.Controls.Add(this.mtxLab6);
            this.groupBox1.Controls.Add(this.MtxRowTbx5);
            this.groupBox1.Controls.Add(this.MtxColTbx10);
            this.groupBox1.Controls.Add(this.MtxRowTbx6);
            this.groupBox1.Controls.Add(this.MtxColTbx5);
            this.groupBox1.Controls.Add(this.mtxLab3);
            this.groupBox1.Controls.Add(this.mtxLab2);
            this.groupBox1.Controls.Add(this.MtxRowTbx7);
            this.groupBox1.Controls.Add(this.MtxColTbx9);
            this.groupBox1.Controls.Add(this.MtxRowTbx8);
            this.groupBox1.Controls.Add(this.MtxColTbx8);
            this.groupBox1.Controls.Add(this.MtxRowTbx9);
            this.groupBox1.Controls.Add(this.MtxColTbx7);
            this.groupBox1.Controls.Add(this.MtxRowTbx10);
            this.groupBox1.Controls.Add(this.MtxColTbx6);
            this.groupBox1.Controls.Add(this.MtxRowTbx4);
            this.groupBox1.Controls.Add(this.MtxColTbx3);
            this.groupBox1.Controls.Add(this.MtxRowTbx3);
            this.groupBox1.Controls.Add(this.MtxColTbx4);
            this.groupBox1.Controls.Add(this.MtxRowTbx2);
            this.groupBox1.Controls.Add(this.MtxColTbx2);
            this.groupBox1.Controls.Add(this.MtxRowTbx1);
            this.groupBox1.Controls.Add(this.MtxColTbx1);
            this.groupBox1.Controls.Add(this.mtxLab1);
            this.groupBox1.Location = new System.Drawing.Point(13, 77);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(602, 497);
            this.groupBox1.TabIndex = 3;
            this.groupBox1.TabStop = false;
            // 
            // mtxLab10
            // 
            this.mtxLab10.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.mtxLab10.Location = new System.Drawing.Point(18, 419);
            this.mtxLab10.Name = "mtxLab10";
            this.mtxLab10.Size = new System.Drawing.Size(52, 37);
            this.mtxLab10.TabIndex = 30;
            // 
            // mtxLab7
            // 
            this.mtxLab7.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.mtxLab7.Location = new System.Drawing.Point(18, 337);
            this.mtxLab7.Name = "mtxLab7";
            this.mtxLab7.Size = new System.Drawing.Size(52, 37);
            this.mtxLab7.TabIndex = 29;
            // 
            // mtxLab8
            // 
            this.mtxLab8.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.mtxLab8.Location = new System.Drawing.Point(18, 374);
            this.mtxLab8.Name = "mtxLab8";
            this.mtxLab8.Size = new System.Drawing.Size(52, 37);
            this.mtxLab8.TabIndex = 28;
            // 
            // mtxLab9
            // 
            this.mtxLab9.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.mtxLab9.Location = new System.Drawing.Point(18, 293);
            this.mtxLab9.Name = "mtxLab9";
            this.mtxLab9.Size = new System.Drawing.Size(52, 37);
            this.mtxLab9.TabIndex = 27;
            // 
            // mtxLab4
            // 
            this.mtxLab4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.mtxLab4.Location = new System.Drawing.Point(18, 208);
            this.mtxLab4.Name = "mtxLab4";
            this.mtxLab4.Size = new System.Drawing.Size(52, 37);
            this.mtxLab4.TabIndex = 26;
            // 
            // mtxLab5
            // 
            this.mtxLab5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.mtxLab5.Location = new System.Drawing.Point(18, 245);
            this.mtxLab5.Name = "mtxLab5";
            this.mtxLab5.Size = new System.Drawing.Size(52, 37);
            this.mtxLab5.TabIndex = 25;
            // 
            // mtxLab6
            // 
            this.mtxLab6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.mtxLab6.Location = new System.Drawing.Point(18, 164);
            this.mtxLab6.Name = "mtxLab6";
            this.mtxLab6.Size = new System.Drawing.Size(52, 37);
            this.mtxLab6.TabIndex = 24;
            // 
            // MtxRowTbx5
            // 
            this.MtxRowTbx5.Location = new System.Drawing.Point(124, 420);
            this.MtxRowTbx5.Name = "MtxRowTbx5";
            this.MtxRowTbx5.Size = new System.Drawing.Size(100, 36);
            this.MtxRowTbx5.TabIndex = 23;
            // 
            // MtxColTbx10
            // 
            this.MtxColTbx10.Location = new System.Drawing.Point(249, 420);
            this.MtxColTbx10.Name = "MtxColTbx10";
            this.MtxColTbx10.Size = new System.Drawing.Size(100, 36);
            this.MtxColTbx10.TabIndex = 22;
            // 
            // MtxRowTbx6
            // 
            this.MtxRowTbx6.Location = new System.Drawing.Point(124, 381);
            this.MtxRowTbx6.Name = "MtxRowTbx6";
            this.MtxRowTbx6.Size = new System.Drawing.Size(100, 36);
            this.MtxRowTbx6.TabIndex = 21;
            // 
            // MtxColTbx5
            // 
            this.MtxColTbx5.Location = new System.Drawing.Point(249, 378);
            this.MtxColTbx5.Name = "MtxColTbx5";
            this.MtxColTbx5.Size = new System.Drawing.Size(100, 36);
            this.MtxColTbx5.TabIndex = 20;
            // 
            // mtxLab3
            // 
            this.mtxLab3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.mtxLab3.Location = new System.Drawing.Point(18, 80);
            this.mtxLab3.Name = "mtxLab3";
            this.mtxLab3.Size = new System.Drawing.Size(52, 37);
            this.mtxLab3.TabIndex = 19;
            // 
            // mtxLab2
            // 
            this.mtxLab2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.mtxLab2.Location = new System.Drawing.Point(18, 117);
            this.mtxLab2.Name = "mtxLab2";
            this.mtxLab2.Size = new System.Drawing.Size(52, 37);
            this.mtxLab2.TabIndex = 18;
            // 
            // MtxRowTbx7
            // 
            this.MtxRowTbx7.Location = new System.Drawing.Point(124, 336);
            this.MtxRowTbx7.Name = "MtxRowTbx7";
            this.MtxRowTbx7.Size = new System.Drawing.Size(100, 36);
            this.MtxRowTbx7.TabIndex = 17;
            // 
            // MtxColTbx9
            // 
            this.MtxColTbx9.Location = new System.Drawing.Point(249, 336);
            this.MtxColTbx9.Name = "MtxColTbx9";
            this.MtxColTbx9.Size = new System.Drawing.Size(100, 36);
            this.MtxColTbx9.TabIndex = 16;
            // 
            // MtxRowTbx8
            // 
            this.MtxRowTbx8.Location = new System.Drawing.Point(124, 297);
            this.MtxRowTbx8.Name = "MtxRowTbx8";
            this.MtxRowTbx8.Size = new System.Drawing.Size(100, 36);
            this.MtxRowTbx8.TabIndex = 15;
            // 
            // MtxColTbx8
            // 
            this.MtxColTbx8.Location = new System.Drawing.Point(249, 294);
            this.MtxColTbx8.Name = "MtxColTbx8";
            this.MtxColTbx8.Size = new System.Drawing.Size(100, 36);
            this.MtxColTbx8.TabIndex = 14;
            // 
            // MtxRowTbx9
            // 
            this.MtxRowTbx9.Location = new System.Drawing.Point(124, 252);
            this.MtxRowTbx9.Name = "MtxRowTbx9";
            this.MtxRowTbx9.Size = new System.Drawing.Size(100, 36);
            this.MtxRowTbx9.TabIndex = 13;
            // 
            // MtxColTbx7
            // 
            this.MtxColTbx7.Location = new System.Drawing.Point(249, 252);
            this.MtxColTbx7.Name = "MtxColTbx7";
            this.MtxColTbx7.Size = new System.Drawing.Size(100, 36);
            this.MtxColTbx7.TabIndex = 12;
            // 
            // MtxRowTbx10
            // 
            this.MtxRowTbx10.Location = new System.Drawing.Point(124, 207);
            this.MtxRowTbx10.Name = "MtxRowTbx10";
            this.MtxRowTbx10.Size = new System.Drawing.Size(100, 36);
            this.MtxRowTbx10.TabIndex = 11;
            // 
            // MtxColTbx6
            // 
            this.MtxColTbx6.Location = new System.Drawing.Point(249, 204);
            this.MtxColTbx6.Name = "MtxColTbx6";
            this.MtxColTbx6.Size = new System.Drawing.Size(100, 36);
            this.MtxColTbx6.TabIndex = 10;
            // 
            // MtxRowTbx4
            // 
            this.MtxRowTbx4.Location = new System.Drawing.Point(124, 165);
            this.MtxRowTbx4.Name = "MtxRowTbx4";
            this.MtxRowTbx4.Size = new System.Drawing.Size(100, 36);
            this.MtxRowTbx4.TabIndex = 9;
            // 
            // MtxColTbx3
            // 
            this.MtxColTbx3.Location = new System.Drawing.Point(249, 165);
            this.MtxColTbx3.Name = "MtxColTbx3";
            this.MtxColTbx3.Size = new System.Drawing.Size(100, 36);
            this.MtxColTbx3.TabIndex = 8;
            // 
            // MtxRowTbx3
            // 
            this.MtxRowTbx3.Location = new System.Drawing.Point(124, 126);
            this.MtxRowTbx3.Name = "MtxRowTbx3";
            this.MtxRowTbx3.Size = new System.Drawing.Size(100, 36);
            this.MtxRowTbx3.TabIndex = 7;
            // 
            // MtxColTbx4
            // 
            this.MtxColTbx4.Location = new System.Drawing.Point(249, 123);
            this.MtxColTbx4.Name = "MtxColTbx4";
            this.MtxColTbx4.Size = new System.Drawing.Size(100, 36);
            this.MtxColTbx4.TabIndex = 6;
            // 
            // MtxRowTbx2
            // 
            this.MtxRowTbx2.Location = new System.Drawing.Point(124, 81);
            this.MtxRowTbx2.Name = "MtxRowTbx2";
            this.MtxRowTbx2.Size = new System.Drawing.Size(100, 36);
            this.MtxRowTbx2.TabIndex = 5;
            // 
            // MtxColTbx2
            // 
            this.MtxColTbx2.Location = new System.Drawing.Point(249, 81);
            this.MtxColTbx2.Name = "MtxColTbx2";
            this.MtxColTbx2.Size = new System.Drawing.Size(100, 36);
            this.MtxColTbx2.TabIndex = 4;
            // 
            // MtxRowTbx1
            // 
            this.MtxRowTbx1.Location = new System.Drawing.Point(124, 36);
            this.MtxRowTbx1.Name = "MtxRowTbx1";
            this.MtxRowTbx1.Size = new System.Drawing.Size(76, 36);
            this.MtxRowTbx1.TabIndex = 2;
            // 
            // MtxColTbx1
            // 
            this.MtxColTbx1.Location = new System.Drawing.Point(249, 33);
            this.MtxColTbx1.Name = "MtxColTbx1";
            this.MtxColTbx1.Size = new System.Drawing.Size(100, 36);
            this.MtxColTbx1.TabIndex = 1;
            // 
            // mtxLab1
            // 
            this.mtxLab1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.mtxLab1.Location = new System.Drawing.Point(18, 36);
            this.mtxLab1.Name = "mtxLab1";
            this.mtxLab1.Size = new System.Drawing.Size(52, 37);
            this.mtxLab1.TabIndex = 0;
            // 
            // analyzeBtn
            // 
            this.analyzeBtn.Location = new System.Drawing.Point(524, 12);
            this.analyzeBtn.Name = "analyzeBtn";
            this.analyzeBtn.Size = new System.Drawing.Size(91, 52);
            this.analyzeBtn.TabIndex = 4;
            this.analyzeBtn.Text = "分析";
            this.analyzeBtn.UseVisualStyleBackColor = true;
            this.analyzeBtn.Click += new System.EventHandler(this.analyzeBtn_Click);
            // 
            // AnsLab2
            // 
            this.AnsLab2.AutoSize = true;
            this.AnsLab2.Location = new System.Drawing.Point(31, 643);
            this.AnsLab2.Name = "AnsLab2";
            this.AnsLab2.Size = new System.Drawing.Size(64, 24);
            this.AnsLab2.TabIndex = 34;
            this.AnsLab2.Text = "label2";
            // 
            // AnsLab1
            // 
            this.AnsLab1.AutoSize = true;
            this.AnsLab1.Location = new System.Drawing.Point(27, 596);
            this.AnsLab1.Name = "AnsLab1";
            this.AnsLab1.Size = new System.Drawing.Size(64, 24);
            this.AnsLab1.TabIndex = 33;
            this.AnsLab1.Text = "label1";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(13F, 24F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(632, 896);
            this.Controls.Add(this.AnsLab2);
            this.Controls.Add(this.AnsLab1);
            this.Controls.Add(this.analyzeBtn);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.Run);
            this.Controls.Add(this.numberTbx);
            this.Controls.Add(this.label1);
            this.Font = new System.Drawing.Font("新細明體", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.Margin = new System.Windows.Forms.Padding(6);
            this.Name = "Form1";
            this.Text = "102 年工科賽第六題 多矩陣相乘運算次數";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox numberTbx;
        private System.Windows.Forms.Button Run;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TextBox MtxColTbx1;
        private System.Windows.Forms.Label mtxLab1;
        private System.Windows.Forms.TextBox MtxRowTbx1;
        private System.Windows.Forms.TextBox MtxColTbx2;
        private System.Windows.Forms.TextBox MtxRowTbx2;
        private System.Windows.Forms.Label mtxLab10;
        private System.Windows.Forms.Label mtxLab7;
        private System.Windows.Forms.Label mtxLab8;
        private System.Windows.Forms.Label mtxLab9;
        private System.Windows.Forms.Label mtxLab4;
        private System.Windows.Forms.Label mtxLab5;
        private System.Windows.Forms.Label mtxLab6;
        private System.Windows.Forms.TextBox MtxRowTbx5;
        private System.Windows.Forms.TextBox MtxColTbx10;
        private System.Windows.Forms.TextBox MtxRowTbx6;
        private System.Windows.Forms.TextBox MtxColTbx5;
        private System.Windows.Forms.Label mtxLab3;
        private System.Windows.Forms.Label mtxLab2;
        private System.Windows.Forms.TextBox MtxRowTbx7;
        private System.Windows.Forms.TextBox MtxColTbx9;
        private System.Windows.Forms.TextBox MtxRowTbx8;
        private System.Windows.Forms.TextBox MtxColTbx8;
        private System.Windows.Forms.TextBox MtxRowTbx9;
        private System.Windows.Forms.TextBox MtxColTbx7;
        private System.Windows.Forms.TextBox MtxRowTbx10;
        private System.Windows.Forms.TextBox MtxColTbx6;
        private System.Windows.Forms.TextBox MtxRowTbx4;
        private System.Windows.Forms.TextBox MtxColTbx3;
        private System.Windows.Forms.TextBox MtxRowTbx3;
        private System.Windows.Forms.TextBox MtxColTbx4;
        private Button analyzeBtn;
        private Label AnsLab2;
        private Label AnsLab1;
    }
}

